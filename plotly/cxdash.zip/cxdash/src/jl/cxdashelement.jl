# AUTO GENERATED FILE - DO NOT EDIT

export cxdashelement

"""
    cxdashelement(;kwargs...)

A CXDashElement component.
CXDashElement implements a Plotly Dash integration of CanvasXpress React.
Properties are defined for use by the CanvasXpress class to update
CanvasXpress aspects such as data, config, and sizing.
Keyword arguments:
- `id` (String; required): The ID of the element for use in function calls and element identification.
- `config` (String; optional): The configuration JSON dictating formatting and content management.
- `data` (String; optional): The data JSON, generally in the XYZ format.
- `events` (String; optional): The events functions for increased reactivity.
- `height` (String; optional): The element height.
- `width` (String; optional): The element width.
"""
function cxdashelement(; kwargs...)
        available_props = Symbol[:id, :config, :data, :events, :height, :width]
        wild_props = Symbol[]
        return Component("cxdashelement", "CXDashElement", "cxdash", available_props, wild_props; kwargs...)
end

