# AUTO GENERATED FILE - DO NOT EDIT

#' @export
cXDashElement <- function(id=NULL, config=NULL, data=NULL, events=NULL, height=NULL, width=NULL) {
    
    props <- list(id=id, config=config, data=data, events=events, height=height, width=width)
    if (length(props) > 0) {
        props <- props[!vapply(props, is.null, logical(1))]
    }
    component <- list(
        props = props,
        type = 'CXDashElement',
        namespace = 'cxdash',
        propNames = c('id', 'config', 'data', 'events', 'height', 'width'),
        package = 'cxdash'
        )

    structure(component, class = c('dash_component', 'list'))
}
