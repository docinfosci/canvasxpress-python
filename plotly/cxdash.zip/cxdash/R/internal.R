.cxdash_js_metadata <- function() {
deps_metadata <- list(`cxdash` = structure(list(name = "cxdash",
version = "0.0.1", src = list(href = NULL,
file = "deps"), meta = NULL,
script = 'cxdash.min.js',
stylesheet = NULL, head = NULL, attachment = NULL, package = "cxdash",
all_files = FALSE), class = "html_dependency"),
`cxdash` = structure(list(name = "cxdash",
version = "0.0.1", src = list(href = NULL,
file = "deps"), meta = NULL,
script = 'cxdash.min.js.map',
stylesheet = NULL, head = NULL, attachment = NULL, package = "cxdash",
all_files = FALSE, dynamic = TRUE), class = "html_dependency"))
return(deps_metadata)
}
